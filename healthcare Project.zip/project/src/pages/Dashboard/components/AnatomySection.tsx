import React from 'react';
import { anatomyData } from '../../../data/healthData';

const AnatomySection: React.FC = () => {
  return (
    <div className="relative h-72">
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="h-full w-1/2 relative">
          <img 
            src="https://images.pexels.com/photos/4226907/pexels-photo-4226907.jpeg?auto=compress&cs=tinysrgb&w=300" 
            alt="Human anatomy illustration" 
            className="h-full w-full object-contain opacity-40"
          />
          
          {anatomyData.map((item) => (
            <div 
              key={item.id}
              className="absolute"
              style={{ 
                top: item.position.top, 
                left: item.position.left,
                transform: 'translate(-50%, -50%)'
              }}
            >
              <div 
                className={`h-3 w-3 rounded-full ${
                  item.status === 'healthy' ? 'bg-green-500' : 'bg-red-500'
                } animate-pulse`}
              ></div>
              <div 
                className="absolute top-4 left-1/2 transform -translate-x-1/2 whitespace-nowrap"
              >
                <p 
                  className={`text-xs font-medium ${
                    item.status === 'healthy' ? 'text-green-600' : 'text-red-600'
                  }`}
                >
                  {item.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AnatomySection;