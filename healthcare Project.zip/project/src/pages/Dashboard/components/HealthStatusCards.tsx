import React from 'react';
import { healthStatusCards } from '../../../data/healthData';

const HealthStatusCards: React.FC = () => {
  return (
    <div className="space-y-4">
      {healthStatusCards.map((card) => (
        <div 
          key={card.id}
          className="p-4 border border-gray-100 rounded-lg shadow-sm hover:shadow-md transition-shadow"
        >
          <div className="flex justify-between items-start mb-1">
            <h3 className="font-medium text-gray-800">{card.name}</h3>
            <span 
              className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${
                card.status === 'healthy' 
                  ? 'bg-green-100 text-green-800' 
                  : 'bg-red-100 text-red-800'
              }`}
            >
              {card.status === 'healthy' ? 'Healthy' : 'Needs Attention'}
            </span>
          </div>
          <p className="text-sm text-gray-500 mb-1">{card.description}</p>
          <p className="text-xs text-gray-400">{card.date}</p>
        </div>
      ))}
    </div>
  );
};

export default HealthStatusCards;