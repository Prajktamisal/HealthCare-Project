import React from 'react';
import { activityData } from '../../../data/appointmentData';

const ActivityFeed: React.FC = () => {
  const maxBarHeight = 60; // Maximum bar height in pixels
  const maxCount = Math.max(...activityData.weeklyDistribution.map(day => day.count));
  
  // Calculate bar height as a percentage of the maximum
  const getBarHeight = (count: number) => {
    if (maxCount === 0) return 0;
    return (count / maxCount) * maxBarHeight;
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold text-gray-800">Activity</h2>
        <span className="text-sm text-gray-500">View all</span>
      </div>
      
      <p className="text-sm text-gray-600 mb-4">
        <span className="font-medium">{activityData.weekTotal} appointments</span> on this week
      </p>
      
      <div className="flex items-end justify-between h-24 mb-2">
        {activityData.weeklyDistribution.map((day, index) => (
          <div key={index} className="flex flex-col items-center">
            <div 
              className={`w-6 ${
                day.count > 0 ? 'bg-blue-500' : 'bg-gray-200'
              } rounded-sm transition-all duration-300`}
              style={{ 
                height: `${getBarHeight(day.count)}px`,
                minHeight: day.count > 0 ? '10px' : '2px'
              }}
            ></div>
          </div>
        ))}
      </div>
      
      <div className="flex justify-between">
        {activityData.weeklyDistribution.map((day, index) => (
          <div key={index} className="text-xs text-gray-500 font-medium">
            {day.day}
          </div>
        ))}
      </div>
    </div>
  );
};

export default ActivityFeed;