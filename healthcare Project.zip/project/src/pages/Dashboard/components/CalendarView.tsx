import React from 'react';
import { Calendar } from 'lucide-react';
import { calendarAppointments, detailedAppointments } from '../../../data/appointmentData';

const CalendarView: React.FC = () => {
  // Generate days for the current month (October for demo)
  const days = Array.from({ length: 31 }, (_, i) => i + 1);
  
  // Day names
  const dayNames = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold text-gray-800">October 2023</h2>
        <button className="text-blue-500 hover:text-blue-600 flex items-center text-sm font-medium">
          <Calendar size={16} className="mr-1" />
          Calendar
        </button>
      </div>
      
      <div className="mb-6">
        {/* Day names row */}
        <div className="grid grid-cols-7 mb-2">
          {dayNames.map((day, index) => (
            <div key={index} className="text-center text-xs text-gray-500 font-medium">
              {day}
            </div>
          ))}
        </div>
        
        {/* Calendar days */}
        <div className="grid grid-cols-7 gap-1">
          {days.map((day) => {
            const appointment = calendarAppointments.find(appt => appt.day === day);
            
            return (
              <div 
                key={day}
                className={`aspect-square flex flex-col justify-center items-center rounded-lg ${
                  appointment 
                    ? 'bg-blue-50 text-blue-700' 
                    : 'hover:bg-gray-50'
                }`}
              >
                <span className={`text-sm ${appointment ? 'font-medium' : ''}`}>{day}</span>
                {appointment && (
                  <span className="text-xs mt-1">{appointment.time}</span>
                )}
              </div>
            );
          })}
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {detailedAppointments.map((appointment) => (
          <div 
            key={appointment.id}
            className="p-4 border border-gray-100 rounded-lg shadow-sm"
          >
            <h3 className="font-medium text-gray-800 mb-1">{appointment.title}</h3>
            <p className="text-sm text-gray-500 mb-1">{appointment.doctor}</p>
            <div className="flex items-center text-xs text-gray-400">
              <span>{appointment.time}</span>
              <span className="mx-1">•</span>
              <span>{appointment.date}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CalendarView;