import React from 'react';
import { upcomingAppointments } from '../../../data/appointmentData';
import { CheckCircle, Eye, Heart, Activity } from 'lucide-react';

const UpcomingSchedule: React.FC = () => {
  return (
    <div>
      <h2 className="text-lg font-semibold text-gray-800 mb-4">The Upcoming Schedule</h2>
      
      <div className="space-y-6">
        {upcomingAppointments.map((daySchedule) => (
          <div key={daySchedule.id}>
            <h3 className="text-sm font-medium text-gray-500 mb-3">
              On {daySchedule.day}
            </h3>
            
            <div className="space-y-3">
              {daySchedule.appointments.map((appointment) => (
                <AppointmentCard 
                  key={appointment.id}
                  title={appointment.title}
                  time={appointment.time}
                  type={appointment.type}
                  icon={appointment.icon}
                />
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

interface AppointmentCardProps {
  title: string;
  time: string;
  type: 'complete' | 'upcoming';
  icon: string;
}

const AppointmentCard: React.FC<AppointmentCardProps> = ({ title, time, type, icon }) => {
  return (
    <div className="flex items-center p-3 border border-gray-100 rounded-lg shadow-sm hover:shadow-md transition-shadow">
      <div className={`p-2 rounded-lg mr-3 ${
        type === 'complete' 
          ? 'bg-green-100 text-green-600' 
          : 'bg-blue-100 text-blue-600'
      }`}>
        {getIcon(icon)}
      </div>
      
      <div className="flex-1">
        <h4 className="text-sm font-medium text-gray-800">{title}</h4>
        <p className="text-xs text-gray-500">{time}</p>
      </div>
      
      <div>
        <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${
          type === 'complete' 
            ? 'bg-green-100 text-green-800' 
            : 'bg-blue-100 text-blue-800'
        }`}>
          {type === 'complete' ? 'Complete' : 'Upcoming'}
        </span>
      </div>
    </div>
  );
};

const getIcon = (iconName: string) => {
  const props = { size: 18 };
  switch (iconName) {
    case 'check-circle': return <CheckCircle {...props} />;
    case 'eye': return <Eye {...props} />;
    case 'heart': return <Heart {...props} />;
    case 'activity': return <Activity {...props} />;
    default: return <Activity {...props} />;
  }
};

export default UpcomingSchedule;