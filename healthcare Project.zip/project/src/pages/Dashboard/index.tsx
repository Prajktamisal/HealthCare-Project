import React from 'react';
import AnatomySection from './components/AnatomySection';
import HealthStatusCards from './components/HealthStatusCards';
import CalendarView from './components/CalendarView';
import UpcomingSchedule from './components/UpcomingSchedule';
import ActivityFeed from './components/ActivityFeed';

const Dashboard: React.FC = () => {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2">
        <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">Health Overview</h2>
          
          <div className="flex flex-col md:flex-row">
            <div className="w-full md:w-1/2 mb-6 md:mb-0 relative">
              <AnatomySection />
            </div>
            <div className="w-full md:w-1/2">
              <HealthStatusCards />
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-6">
          <CalendarView />
        </div>
      </div>
      
      <div className="lg:col-span-1">
        <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
          <UpcomingSchedule />
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-6">
          <ActivityFeed />
        </div>
      </div>
    </div>
  );
};

export default Dashboard;