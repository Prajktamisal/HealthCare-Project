import React from 'react';
import { Search, Bell, Plus } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-white border-b border-gray-200 py-4 px-6 flex items-center justify-between">
      <div className="flex items-center">
        <h1 className="text-xl font-bold text-blue-600">Healthcare.</h1>
        
        <div className="hidden md:flex ml-8 relative">
          <input
            type="text"
            placeholder="Search..."
            className="pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent w-64"
          />
          <Search className="absolute left-3 top-2.5 text-gray-400" size={18} />
        </div>
      </div>
      
      <div className="flex items-center space-x-4">
        <button className="relative p-2 rounded-full hover:bg-gray-100">
          <Bell size={20} className="text-gray-600" />
          <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
        </button>
        
        <button className="p-2 bg-blue-500 text-white rounded-full hover:bg-blue-600">
          <Plus size={20} />
        </button>
        
        <div className="flex items-center">
          <div className="h-9 w-9 rounded-full bg-blue-100 overflow-hidden">
            <img 
              src="https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=150"
              alt="User avatar"
              className="h-full w-full object-cover"
            />
          </div>
          <div className="ml-3 hidden md:block">
            <p className="text-sm font-medium text-gray-700">Dr. Smith</p>
            <p className="text-xs text-gray-500">Cardiologist</p>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;