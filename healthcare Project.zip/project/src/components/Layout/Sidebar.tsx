import React from 'react';
import { Home, Clock, Calendar, FileText, BarChart2, TestTube, MessageSquare, HelpCircle, Settings } from 'lucide-react';
import { navigationLinks } from '../../data/navigationData';

const Sidebar: React.FC = () => {
  return (
    <aside className="w-16 md:w-64 bg-white border-r border-gray-200 flex-shrink-0 hidden md:block">
      <div className="h-full flex flex-col py-6">
        <div className="px-6 mb-6">
          <h2 className="text-xs uppercase font-semibold text-gray-500">General</h2>
        </div>
        
        <nav className="flex-1 space-y-1 px-3">
          {navigationLinks.map((item) => (
            <SidebarLink 
              key={item.name}
              name={item.name} 
              icon={getIcon(item.icon)} 
              isActive={item.isActive} 
            />
          ))}
        </nav>
      </div>
    </aside>
  );
};

interface SidebarLinkProps {
  name: string;
  icon: React.ReactNode;
  isActive?: boolean;
}

const SidebarLink: React.FC<SidebarLinkProps> = ({ name, icon, isActive }) => {
  return (
    <a 
      href="#" 
      className={`flex items-center px-3 py-2 rounded-lg text-sm font-medium ${
        isActive 
          ? 'bg-blue-50 text-blue-600' 
          : 'text-gray-700 hover:bg-gray-50 hover:text-gray-900'
      }`}
    >
      <span className="mr-3">{icon}</span>
      <span className="hidden md:block">{name}</span>
    </a>
  );
};

const getIcon = (iconName: string) => {
  const props = { size: 20 };
  switch (iconName) {
    case 'home': return <Home {...props} />;
    case 'clock': return <Clock {...props} />;
    case 'calendar': return <Calendar {...props} />;
    case 'file-text': return <FileText {...props} />;
    case 'bar-chart-2': return <BarChart2 {...props} />;
    case 'test-tube': return <TestTube {...props} />;
    case 'message-square': return <MessageSquare {...props} />;
    case 'help-circle': return <HelpCircle {...props} />;
    case 'settings': return <Settings {...props} />;
    default: return <Home {...props} />;
  }
};

export default Sidebar;