export const anatomyData = [
  {
    id: 1,
    name: 'Heart',
    status: 'healthy',
    position: { top: '35%', left: '50%' },
    description: 'Healthy Heart'
  },
  {
    id: 2,
    name: 'Lungs',
    status: 'issue',
    position: { top: '30%', left: '55%' },
    description: 'Lungs'
  },
  {
    id: 3,
    name: 'Teeth',
    status: 'healthy',
    position: { top: '15%', left: '50%' },
    description: 'Teeth'
  },
  {
    id: 4,
    name: 'Bone',
    status: 'healthy',
    position: { top: '60%', left: '45%' },
    description: 'Bone'
  }
];

export const healthStatusCards = [
  {
    id: 1,
    name: 'Lungs',
    status: 'issue',
    date: 'Oct 15, 2023',
    description: 'Minor inflammation detected'
  },
  {
    id: 2,
    name: 'Teeth',
    status: 'healthy',
    date: 'Oct 10, 2023',
    description: 'Regular checkup completed'
  },
  {
    id: 3,
    name: 'Bone',
    status: 'healthy',
    date: 'Sep 28, 2023',
    description: 'Bone density normal'
  }
];