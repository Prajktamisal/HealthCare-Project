export const navigationLinks = [
  {
    name: 'Dashboard',
    icon: 'home',
    isActive: true
  },
  {
    name: 'History',
    icon: 'clock',
  },
  {
    name: 'Calendar',
    icon: 'calendar',
  },
  {
    name: 'Appointments',
    icon: 'file-text',
  },
  {
    name: 'Statistics',
    icon: 'bar-chart-2',
  },
  {
    name: 'Tests',
    icon: 'test-tube',
  },
  {
    name: 'Chat',
    icon: 'message-square',
  },
  {
    name: 'Support',
    icon: 'help-circle',
  },
  {
    name: 'Settings',
    icon: 'settings',
  }
];