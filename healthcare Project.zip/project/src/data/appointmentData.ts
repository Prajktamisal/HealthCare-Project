export const calendarAppointments = [
  { id: 1, day: 4, time: '09:00', title: 'General Checkup' },
  { id: 2, day: 10, time: '11:00', title: 'Dental Appointment' },
  { id: 3, day: 15, time: '13:00', title: 'Lung Examination' },
  { id: 4, day: 22, time: '15:00', title: 'Physiotherapy' },
];

export const detailedAppointments = [
  {
    id: 1,
    title: 'Dentist',
    doctor: 'Dr. Johnson',
    time: '11:00 AM',
    date: 'October 10, 2023',
    icon: 'tooth'
  },
  {
    id: 2,
    title: 'Physiotherapy Appointment',
    doctor: 'Dr. Williams',
    time: '3:00 PM',
    date: 'October 22, 2023',
    icon: 'activity'
  }
];

export const upcomingAppointments = [
  {
    id: 1,
    day: 'Thursday',
    appointments: [
      {
        id: 101,
        title: 'Health checkup complete',
        time: '9:00 AM',
        type: 'complete',
        icon: 'check-circle'
      },
      {
        id: 102,
        title: 'Ophthalmologist',
        time: '11:30 AM',
        type: 'upcoming',
        icon: 'eye'
      }
    ]
  },
  {
    id: 2,
    day: 'Saturday',
    appointments: [
      {
        id: 201,
        title: 'Cardiologist',
        time: '10:00 AM',
        type: 'upcoming',
        icon: 'heart'
      },
      {
        id: 202,
        title: 'Neurologist',
        time: '2:30 PM',
        type: 'upcoming',
        icon: 'activity'
      }
    ]
  }
];

export const activityData = {
  weekTotal: 3,
  weeklyDistribution: [
    { day: 'Mon', count: 0 },
    { day: 'Tue', count: 1 },
    { day: 'Wed', count: 0 },
    { day: 'Thu', count: 2 },
    { day: 'Fri', count: 0 },
    { day: 'Sat', count: 0 },
    { day: 'Sun', count: 0 }
  ]
};